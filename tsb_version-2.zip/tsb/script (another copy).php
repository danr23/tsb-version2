<?php
error_reporting(0);

$tsbget = $_GET['tsb'];
$tsbgetp = $_GET['tsbp'];
$hash = md5($tsbget);
$hashp = md5($tsbgetp);
//echo $hash;
//echo $hashp;
$s = ' ';



$arrayHash = [

[
"093f65e080a295f8076b1c5722a46aa2",
"f379cfd7a55b621577a8389d1817a102",
"55496",
"4",
"41",
],

[
"350db081a661525235354dd3e19b8c05",
"ea82410c7a9991816b5eeeebe195e20a",
"9849",
"-2078",
"9849",
],

[
"d18f655c3fce66ca401d5f38b48c89af",
"a363b8d13575101a0226e8d0d054f2e7",
"9520",
"-381",
"520",
],

[
"f899139df5e1059396431415e770c6dd",
"aab92e69374e4c7b8c6741fe02e574b9",
"11012",
"-36",
"11013",
],

[
"a5771bce93e200c36f7cd9dfd0e5deaa",
"fff25994ee3941b225ba898fd17d186f",
"6964",
"67",
"20",
],

[
"d645920e395fedad7bbbed0eca3fe2e0",
"8b04d5e3775d298e78455efc5ca404d5",
"499960",
"71",
"-500040",
],




















];
/* 
$arrayHash = [
"093f65e080a295f8076b1c5722a46aa2",
"350db081a661525235354dd3e19b8c05",
"d18f655c3fce66ca401d5f38b48c89af",
"f899139df5e1059396431415e770c6dd",
"a5771bce93e200c36f7cd9dfd0e5deaa",
"d645920e395fedad7bbbed0eca3fe2e0",

];

$arrayHashp = [
"f379cfd7a55b621577a8389d1817a102",
"ea82410c7a9991816b5eeeebe195e20a",
"a363b8d13575101a0226e8d0d054f2e7",
"aab92e69374e4c7b8c6741fe02e574b9",
"fff25994ee3941b225ba898fd17d186f",
"8b04d5e3775d298e78455efc5ca404d5",

];
$arrayx = [
"55496",
"9849",
"9520",
"11012",
"6964",
"499960",

];
$arrayy = [
"4",
"-2078",
"-381",
"-36",
"67",
"71",

];
$arrayz = [
"41",
"9849",
"520",
"11013",
"20",
"-500040",

];
*/

foreach ($arrayHash as list($a, $b, $c, $d, $e)) {
if ($hash == $a && $hashp == $b) {
$x = $tsbget+$c;
$y = $tsbget+$d;
$z = $tsbget+$e;
$xyz = $x.$s.$y.$s.$z;
echo '<html>
<head>
<meta charset="utf-8">
<title>TSB</title>
<script src="copyjs.js"></script>
<link rel="stylesheet" type="text/css" href="stylecopy.css">
</head>
<body align="center" bgcolor="#ff0000">
<div align="center">

<table border="1" align="center" bgcolor="#cc0000">
<tr>
<td class="tsbStyleX">X = ';echo $x;echo ' </td><td class="tsbStyleY">Y = ';echo $y;echo ' </td><td class="tsbStyleZ">Z = ';echo $z;echo '</td><td class="tsbStyleZ">pw = ';echo $tsbgetp;echo '</td>
</tr>

</table>
<br><br>
<form>
<input type="text" id="tsbT" value="';echo $xyz;echo '" disabled="true" class="tsbTextStyle">
</input>
</form>
<button onclick="copy()" class="tsbStyleCopyTextBtn">Copy TSB cordinates</button>
<br><br>
<b class="tsbStyleCopyText">Copy: <span id="resultCopy">-</span></b>
</div>
</body>
</html>
';

}
//wrong
else {
echo '
<html>
<head>
<meta charset="utf-8">
<title>TSB</title>
<script src="copyjs.js"></script>
<link rel="stylesheet" type="text/css" href="stylecopy.css">
</head>
<body align="center" bgcolor="#ffcc00">
<div align="center">
Sorry, you are entering incorrect information.<br>
The hash sums entered were not found in the database.<br>
Your number hash: ';echo $hash;echo ' <br>
Your word hash: ';echo $hashp;echo ' <br>
</div></body></html>
';
};




};

/*
//1

if ($hash == "093f65e080a295f8076b1c5722a46aa2" && $hashp == "f379cfd7a55b621577a8389d1817a102") {
$x = $tsbget+55496;
$y = $tsbget+4;
$z = $tsbget+41;
$xyz = $x.$s.$y.$s.$z;
echo '<html>
<head>
<meta charset="utf-8">
<title>TSB</title>
<script src="copyjs.js"></script>
<link rel="stylesheet" type="text/css" href="stylecopy.css">
</head>
<body align="center" bgcolor="#ff0000">
<div align="center">

<table border="1" align="center" bgcolor="#cc0000">
<tr>
<td class="tsbStyleX">X = ';echo $x;echo ' </td><td class="tsbStyleY">Y = ';echo $y;echo ' </td><td class="tsbStyleZ">Z = ';echo $z;echo '</td><td class="tsbStyleZ">pw = ';echo $tsbgetp;echo '</td>
</tr>

</table>
<br><br>
<form>
<input type="text" id="tsbT" value="';echo $xyz;echo '" disabled="true" class="tsbTextStyle">
</input>
</form>
<button onclick="copy()" class="tsbStyleCopyTextBtn">Copy TSB cordinates</button>
<br><br>
<b class="tsbStyleCopyText">Copy: <span id="resultCopy">-</span></b>
</div>
</body>
</html>
';

}

//2

else 
if ($hash == "350db081a661525235354dd3e19b8c05" && $hashp == "ea82410c7a9991816b5eeeebe195e20a") {
$x = $tsbget+9849;
$y = $tsbget+-2078;
$z = $tsbget+9849;
$xyz = $x.$s.$y.$s.$z;
echo '<html>
<head>
<meta charset="utf-8">
<title>TSB</title>
<script src="copyjs.js"></script>
<link rel="stylesheet" type="text/css" href="stylecopy.css">
</head>
<body align="center" bgcolor="#ff0000">
<div align="center">

<table border="1" align="center" bgcolor="#cc0000">
<tr>
<td class="tsbStyleX">X = ';echo $x;echo ' </td><td class="tsbStyleY">Y = ';echo $y;echo ' </td><td class="tsbStyleZ">Z = ';echo $z;echo '</td><td class="tsbStyleZ">pw = ';echo $tsbgetp;echo '</td>
</tr>

</table>
<br><br>
<form>
<input type="text" id="tsbT" value="';echo $xyz;echo '" disabled="true" class="tsbTextStyle">
</input>
</form>
<button onclick="copy()" class="tsbStyleCopyTextBtn">Copy TSB cordinates</button>
<br><br>
<b class="tsbStyleCopyText">Copy: <span id="resultCopy">-</span></b>
</div>
</body>
</html>
';

} 



//3

else 
if ($hash == "d18f655c3fce66ca401d5f38b48c89af" && $hashp == "a363b8d13575101a0226e8d0d054f2e7") {
$x = $tsbget+9520;
$y = $tsbget+-381;
$z = $tsbget+520;
$xyz = $x.$s.$y.$s.$z;
echo '<html>
<head>
<meta charset="utf-8">
<title>TSB</title>
<script src="copyjs.js"></script>
<link rel="stylesheet" type="text/css" href="stylecopy.css">
</head>
<body align="center" bgcolor="#ff0000">
<div align="center">

<table border="1" align="center" bgcolor="#cc0000">
<tr>
<td class="tsbStyleX">X = ';echo $x;echo ' </td><td class="tsbStyleY">Y = ';echo $y;echo ' </td><td class="tsbStyleZ">Z = ';echo $z;echo '</td><td class="tsbStyleZ">pw = ';echo $tsbgetp;echo '</td>
</tr>

</table>
<br><br>
<form>
<input type="text" id="tsbT" value="';echo $xyz;echo '" disabled="true" class="tsbTextStyle">
</input>
</form>
<button onclick="copy()" class="tsbStyleCopyTextBtn">Copy TSB cordinates</button>
<br><br>
<b class="tsbStyleCopyText">Copy: <span id="resultCopy">-</span></b>
</div>
</body>
</html>
';

} 



//4

else 
if ($hash == "f899139df5e1059396431415e770c6dd" && $hashp == "aab92e69374e4c7b8c6741fe02e574b9") {
$x = $tsbget+11012;
$y = $tsbget+-36;
$z = $tsbget+11013;
$xyz = $x.$s.$y.$s.$z;
echo '<html>
<head>
<meta charset="utf-8">
<title>TSB</title>
<script src="copyjs.js"></script>
<link rel="stylesheet" type="text/css" href="stylecopy.css">
</head>
<body align="center" bgcolor="#ff0000">
<div align="center">

<table border="1" align="center" bgcolor="#cc0000">
<tr>
<td class="tsbStyleX">X = ';echo $x;echo ' </td><td class="tsbStyleY">Y = ';echo $y;echo ' </td><td class="tsbStyleZ">Z = ';echo $z;echo '</td><td class="tsbStyleZ">pw = ';echo $tsbgetp;echo '</td>
</tr>

</table>
<br><br>
<form>
<input type="text" id="tsbT" value="';echo $xyz;echo '" disabled="true" class="tsbTextStyle">
</input>
</form>
<button onclick="copy()" class="tsbStyleCopyTextBtn">Copy TSB cordinates</button>
<br><br>
<b class="tsbStyleCopyText">Copy: <span id="resultCopy">-</span></b>
</div>
</body>
</html>
';

} 



//5

else 
if ($hash == "a5771bce93e200c36f7cd9dfd0e5deaa" && $hashp == "fff25994ee3941b225ba898fd17d186f") {
$x = $tsbget+6964;
$y = $tsbget+67;
$z = $tsbget+20;
$xyz = $x.$s.$y.$s.$z;
echo '<html>
<head>
<meta charset="utf-8">
<title>TSB</title>
<script src="copyjs.js"></script>
<link rel="stylesheet" type="text/css" href="stylecopy.css">
</head>
<body align="center" bgcolor="#ff0000">
<div align="center">

<table border="1" align="center" bgcolor="#cc0000">
<tr>
<td class="tsbStyleX">X = ';echo $x;echo ' </td><td class="tsbStyleY">Y = ';echo $y;echo ' </td><td class="tsbStyleZ">Z = ';echo $z;echo '</td><td class="tsbStyleZ">pw = ';echo $tsbgetp;echo '</td>
</tr>

</table>
<br><br>
<form>
<input type="text" id="tsbT" value="';echo $xyz;echo '" disabled="true" class="tsbTextStyle">
</input>
</form>
<button onclick="copy()" class="tsbStyleCopyTextBtn">Copy TSB cordinates</button>
<br><br>
<b class="tsbStyleCopyText">Copy: <span id="resultCopy">-</span></b>
</div>
</body>
</html>
';

} 



//6

else 
if ($hash == "d645920e395fedad7bbbed0eca3fe2e0" && $hashp == "8b04d5e3775d298e78455efc5ca404d5") {
$x = $tsbget+499960;
$y = $tsbget+71;
$z = $tsbget+-500040;
$xyz = $x.$s.$y.$s.$z;
echo '<html>
<head>
<meta charset="utf-8">
<title>TSB</title>
<script src="copyjs.js"></script>
<link rel="stylesheet" type="text/css" href="stylecopy.css">
</head>
<body align="center" bgcolor="#ff0000">
<div align="center">

<table border="1" align="center" bgcolor="#cc0000">
<tr>
<td class="tsbStyleX">X = ';echo $x;echo ' </td><td class="tsbStyleY">Y = ';echo $y;echo ' </td><td class="tsbStyleZ">Z = ';echo $z;echo '</td><td class="tsbStyleZ">pw = ';echo $tsbgetp;echo '</td>
</tr>

</table>
<br><br>
<form>
<input type="text" id="tsbT" value="';echo $xyz;echo '" disabled="true" class="tsbTextStyle">
</input>
</form>
<button onclick="copy()" class="tsbStyleCopyTextBtn">Copy TSB cordinates</button>
<br><br>
<b class="tsbStyleCopyText">Copy: <span id="resultCopy">-</span></b>
</div>
</body>
</html>
';

} 




//wrong
else {
echo '
<html>
<head>
<meta charset="utf-8">
<title>TSB</title>
<script src="copyjs.js"></script>
<link rel="stylesheet" type="text/css" href="stylecopy.css">
</head>
<body align="center" bgcolor="#ffcc00">
<div align="center">
Sorry, you are entering incorrect information.<br>
The hash sums entered were not found in the database.<br>
Your number hash: ';echo $hash;echo ' <br>
Your word hash: ';echo $hashp;echo ' <br>
</div></body></html>
';
};
*/

?>



