<?php
error_reporting(0);

$tsbget = $_GET['tsb'];

$x = $tsbget+499960;
$y = $tsbget+71;
$z = $tsbget+-500040;
$s = ' ';
$xyz = $x.$s.$y.$s.$z;
?>

<html>
<head>
<meta charset="utf-8">
<title>TSB</title>
<script src="copyjs.js"></script>
<link rel="stylesheet" type="text/css" href="stylecopy.css">
</head>
<body align="center" bgcolor="#ff0000">
<div align="center">

<table border="1" align="center" bgcolor="#cc0000">
<tr>
<td class="tsbStyleX">X = <?php echo $x; ?></td><td class="tsbStyleY">Y = <?php echo $y; ?></td><td class="tsbStyleZ">Z = <?php echo $z; ?></td>
</tr>

</table>
<br><br>
<form>
<input type="text" id="tsbT" value="<?php echo $xyz; ?>" disabled="true" class="tsbTextStyle">
</input>
</form>
<button onclick="copy()" class="tsbStyleCopyTextBtn">Copy TSB cordinates</button>
<br><br>
<b class="tsbStyleCopyText">Copy: <span id="resultCopy">-</span></b>
</div>
</body>
</html>
